# Punto Limpio — versión lista para publicar

## Qué contiene
- Página moderna responsive para celular.
- Secciones de explicación, puntos, beneficios y opinión.
- Contador de puntos funcional como DEMO en el navegador.
- Estructura preparada para conectar un backend.

## Importante sobre "puntos reales"
Para que los puntos sean reales y compartidos entre distintos celulares, hay que conectar una base de datos y un sistema de identificación. Esta carpeta no inventa esa parte: el contador actual es local.

## Publicación
Puedes subir `index.html`, `style.css` y `app.js` a un servicio de hosting estático como GitHub Pages o Netlify.

## QR
El QR debe contener la URL pública final (por ejemplo, la URL de GitHub Pages). Si generas el QR antes de publicar, no podrá llevar a la página definitiva.
