let score=Number(localStorage.getItem("punto_limpio_score")||0);
const scoreEl=document.getElementById("score");
const add=document.getElementById("addPoint");
function render(){scoreEl.textContent=score}
render();
add.addEventListener("click",()=>{score+=10;localStorage.setItem("punto_limpio_score",score);render()});

document.getElementById("opinionForm").addEventListener("submit",e=>{
  e.preventDefault();
  const msg=document.getElementById("formMsg");
  msg.textContent="¡Gracias por participar! En la versión conectada, esta respuesta se guardará en la base de datos.";
  msg.className="message";
});
